
export var a={
    name:"000"
}