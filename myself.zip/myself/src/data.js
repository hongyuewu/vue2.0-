export var list=[{name:"饿哦的二二而我居然",info:"55453455434<br/>38428423848923<br/>38428423848923"},{name:"饿哦的二二而我居111",info:"grgretetertertretretetetret<br/>38428423848923<br/>38428423848923"}]
