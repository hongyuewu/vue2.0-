import Mock from 'mockjs';
export default Mock.mock('http://g.cn', {
	'name'    : '@cname',
	'age|18-25': 100
});