<template>
    <div>
        <div>
            <img src="../assets/logo.png"/>
        </div>
        
    </div>
</template>
<style lang="scss" scoped="" type="text/css">
</style>

<script type="text/javascript">
	function a(name){	    
	    this.name=name;	    
	}
	var pes=new a('aaa')
</script>